//
//  ViewController.swift
//  Almofire
//
//  Created by MACOS on 6/15/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit
import Alamofire


class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    @IBOutlet weak var txtid: UITextField!
    @IBOutlet weak var txtemail: UITextField!
    @IBOutlet weak var txtpwd: UITextField!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet var tbl: UITableView!
    
    var final = [Any]()
    let picker = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        txtid.isHidden = true
        
        Alamofire.request("http://localhost/moin/select.php").responseJSON { response in
            print("Request: \(response.request)")
            print("Response: \(response.response)")
            print("Error: \(response.error)")
            print("Result: \(response.result)")
            print("Data: \(response.data)")
            
            
            if let JSON = response.result.value {
                print("JSON: \(JSON)")
                
                do
                {
                    let dt = try JSONSerialization.jsonObject(with: response.data!, options: []) as! [Any]
                    
                    for i in dt
                    {
                        self.final.append(i)
                        self.tbl.reloadData()
                    }
                }
                catch
                {
                    
                }
                print(self.final)
            }

        }
        
    }

    @IBAction func btnInsert(_ sender: Any) {
        
        var paramiter : Parameters = [:]
        
        let img1 = img.image;
        let imgdata = UIImageJPEGRepresentation(img1!, 1.0);
       
        let base64 = imgdata?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters);
        
        paramiter["email"] = txtemail.text
        paramiter["password"] = txtpwd.text
        paramiter["image"] = base64!
        
        Alamofire.request("http://localhost/moin/insert.php", method: .post, parameters: paramiter, encoding: URLEncoding.httpBody).responseString{ response in
            print(response.request ?? "hj")  // original URL request
            print(response.response ?? "hg") // HTTP URL response
            print(response.data ?? "gf")     // server data
            print(response.result)   // result of response serialization
            
            if let JSON = response.result.value {
                print("JSON: \(JSON)")
            }
            
        }
        self.tbl.reloadData()

    }
    
    @IBAction func btnUpdate(_ sender: Any) {
        
        var paramiter : Parameters = [:]
        
        paramiter["Id"] = txtid.text
        paramiter["email"] = txtemail.text
        paramiter["password"] = txtpwd.text
        
        Alamofire.request("http://localhost/moin/update.php", method: .post, parameters: paramiter, encoding: URLEncoding.httpBody).responseString{ response in
            print(response.request ?? "hj")  // original URL request
            print(response.response ?? "hg") // HTTP URL response
            print(response.data ?? "gf")     // server data
            print(response.result)   // result of response serialization
            
            if let JSON = response.result.value {
                print("JSON: \(JSON)")
                self.tbl.reloadData()
            }
        }
    }
    
    @IBAction func btnDelete(_ sender: Any) {
        var paramiter : Parameters = [:]
        
        paramiter["Id"] = txtid.text
        
        Alamofire.request("http://localhost/moin/delete.php", method: .post, parameters: paramiter, encoding: URLEncoding.httpBody).responseString{ response in
            print(response.request ?? "hj")  // original URL request
            print(response.response ?? "hg") // HTTP URL response
            print(response.data ?? "gf")     // server data
            print(response.result)   // result of response serialization
            
            if let JSON = response.result.value {
                print("JSON: \(JSON)")
                self.tbl.reloadData()
            }
        }
        

    }
    
    @IBAction func btnLogin(_ sender: Any) {
        var paramiter : Parameters = [:]
        
        paramiter["email"] = txtemail.text
        paramiter["password"] = txtpwd.text
        
        Alamofire.request("http://localhost/moin/login.php", method: .post, parameters: paramiter, encoding: URLEncoding.httpBody).responseString{ response in
            print(response.request ?? "hj")  // original URL request
            print(response.response ?? "hg") // HTTP URL response
            print(response.data ?? "gf")     // server data
            print(response.result)   // result of response serialization
            
            if let JSON = response.result.value {
                print("JSON: \(JSON)")
            
                self.tbl.reloadData()
            }
            else
            {
                print("Something wrong")
            }
        }

    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return final.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        
        let dicfinal = final[indexPath.row] as! [String:Any]
      
        cell?.textLabel?.text = dicfinal["email"] as? String
        cell?.detailTextLabel?.text = dicfinal["password"] as? String
        
       
        // Retrive image from database
        var img1:String = ""
        let path = dicfinal["image"] as? String;
        let str = "http://localhost/moin/" + path!
        img1.append(str)
        
        let url = URL(string: str)
        
        do{
            let data = try Data(contentsOf: url!)
            //print(data)
            
            cell?.imageView?.image = UIImage(data: data);
            
        }
        catch
        {
            
        }

        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let dicfinal2 = final[indexPath.row] as! [String:Any]
        
        txtid.text = dicfinal2["Id"] as! String
        txtemail.text = dicfinal2["email"] as! String
        txtpwd.text = dicfinal2["password"] as! String
    }
    
    @IBAction func btnPickImage(_ sender: Any) {
        picker.sourceType = UIImagePickerControllerSourceType.photoLibrary
        picker.delegate = self
        self.present(picker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        img.image = info[UIImagePickerControllerOriginalImage] as! UIImage
        
        self.dismiss(animated: true, completion: nil)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

