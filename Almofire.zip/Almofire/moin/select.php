<?php
    $con=new mysqli("localhost","root","","mydb");
    
    
    //$email=$_POST['stud_enrollno'];
		
        
    $query = "SELECT * from user";
    
        $rows= $con->query($query);
        
            while($row = $rows -> fetch_assoc())
            {
                $pp[]=$row;
            }
            echo json_encode($pp);
    
?>
