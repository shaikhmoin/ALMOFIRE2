<?php

    $con=new MySQLi("localhost","root","","mydb");
    
    $id = $_POST["Id"];
    $email = $_POST["email"];
    $pwd = $_POST["password"];

    
    echo $qu="update user set email='$email', password='$pwd' where Id='$id'";

    $con->query($qu);
    
    echo "success";
    
?>

