<?php
    $con=new mysqli("localhost","root","","mydb");
    
    
    $email=$_POST['email'];
    $pwd=$_POST['password'];
    
        
    $query = "SELECT * from user where email='$email' and password='$pwd'";
    
        $rows= $con->query($query);
        
            while($row = $rows -> fetch_assoc())
            {
                $pp[]=$row;
            }
            echo json_encode($pp);
    
?>
