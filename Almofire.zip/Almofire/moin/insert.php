<?php
    $con=new mysqli("localhost","root","","mydb");

    define('UPLOAD_DIR', 'images/');

    $img = $_POST['image'];
    
    $img = str_replace('data:image/png;base64,', '', $img);
    $img = str_replace(' ', '+', $img);
    $data = base64_decode($img);
    $file = UPLOAD_DIR . uniqid() . '.png';
    $success = file_put_contents($file, $data);
    print $success ? $file : 'Unable to save the file.';

    $email = $_POST["email"];
    $pwd = $_POST["password"];
    $img1 = $_POST["image"];
    
    $query = "insert into user(email,password,image)values('$email','$pwd','$file')";
    
    $con -> query($query);
    echo "success";   
?>


    

