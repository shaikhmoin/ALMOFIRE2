<?php
    $con=new mysqli("localhost","root","","mydb");
    
    
    $a = $_POST['Id'];
   // print($a);
    
   echo $qp="delete from user where Id='$a'";
    
    $con -> query($qp);
    echo "success";
   
?>
